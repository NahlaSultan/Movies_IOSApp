//
//  MovieCell.swift
//  Movies
//
//  Copyright © 2020 Nahla. All rights reserved.
//

import UIKit

class MovieCell: UITableViewCell {
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    @IBOutlet var titleLabel: UILabel!
//    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
//    @IBOutlet weak var overviewLabel: UILabel!
//    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet var overviewLabel: UILabel!
    @IBOutlet var imgView: UIImageView!
    
//    func setup(movie: MovieModel) {
//        titleLabel.text = movie.title
//        dateLabel.text = movie.release_date
//        overviewLabel.text = movie.overview
//
//    }
}
