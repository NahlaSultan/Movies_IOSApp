//
//  MoviesTests.swift
//  MoviesTests
//
//  Created by MacBook on 5/21/20.
//  Copyright © 2020 Nahla. All rights reserved.
//
@testable import Movies
import XCTest

class addMovieTests: XCTestCase {

    var SUT:AddMovieViewController!

    override func setUpWithError() throws {
         let storyboard = UIStoryboard(name: "Main", bundle: nil)

        let addMovieViewController: AddMovieViewController = storyboard.instantiateViewController(withIdentifier: "AddMovieViewController") as! AddMovieViewController

              SUT = addMovieViewController

             _ = addMovieViewController.view

    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }




    
    func testMovieModelInit() throws{
        
        let movieModel = MovieModel(title: "", overview: "", release_date: "", poster_path: "")
        
            XCTAssertNotNil(movieModel)
    }

    
    func testPosterImageView() throws{
    
        XCTAssertNotNil(SUT.addImageView,"Must have a UIImage view for Movie Poster")
     }
    
    func testTitleTxtField() throws{
      
        XCTAssertNotNil(SUT.titleTextField,"Must have a text field to type in a new movie title")
       }
    
    func testOverviewTxtField() throws{
         
        XCTAssertNotNil(SUT.overviewTextField,"Must have an overview field to type in a new movie overview")
          }
    
    func testDateTxtField() throws{
         
        XCTAssertNotNil(SUT.overviewTextField,"Must have an date field to type in a new movie date")
          }

    func testMyMoviesArray() throws{
        
        XCTAssertNotNil(SUT.decodeMoviesArray(),"My Movies array is nil, something wrong with decode method")
       
    }

}

