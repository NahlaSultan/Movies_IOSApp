//
//  MyMoviesTests.swift
//  MoviesTests
//
//  Created by MacBook on 5/21/20.
//  Copyright © 2020 Nahla. All rights reserved.
//
@testable import Movies
import XCTest

class myMovieTests: XCTestCase {

    var SUT:MyMovieViewController!

    override func setUpWithError() throws {
         let storyboard = UIStoryboard(name: "Main", bundle: nil)

        let addMovieViewController: MyMovieViewController = storyboard.instantiateViewController(withIdentifier: "MyMovieViewController") as! MyMovieViewController

              SUT = addMovieViewController

             _ = addMovieViewController.view

    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testMovieModelInit() throws{
        
        let movieModel = MovieModel(title: "", overview: "", release_date: "", poster_path: "")
        
            XCTAssertNotNil(movieModel)
    }

    
    func testPosterImageView() throws{
    
        XCTAssertNotNil(SUT.myMovies,"Must have a movie array to store movies")
     }
    
    func testTitleTxtField() throws{
      
        XCTAssertNotNil(SUT.tableView,"Must have a table view to display movies")
       }
    
   


}
