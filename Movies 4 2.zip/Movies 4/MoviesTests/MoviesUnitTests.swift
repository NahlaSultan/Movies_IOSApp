//
//  MoviesUnitTests.swift
//  MoviesUnitTests
//
//  Created by MacBook on 5/20/20.
//  Copyright © 2020 Nahla. All rights reserved.
//

import XCTest



class MoviesUnitTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        let app = XCUIApplication()
        app.launch()
        
        app.buttons["addNewMovieBtn"].tap()

    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }

}
