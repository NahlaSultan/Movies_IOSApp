import UIKit

class AddMovieViewController: UIViewController {
    
    @IBOutlet weak var titleTextField: UITextField!
        
    @IBOutlet weak var overviewTextField: UITextField!
        
    @IBOutlet weak var dateTextField: UITextField!
    
    @IBOutlet weak var posterImageView: UIImageView!
    
    @IBOutlet weak var addImageView: UIImageView!
    
    let encoder  = PropertyListEncoder()
    //path to store myMovies array
    let dataFilePath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("MyMovies.plist")
    var encodedImage = ""
    var movieArray = [MovieModel]()


    override func viewDidLoad() {
        super.viewDidLoad()
    }
        
    //Button Actions///////////////
    
    //add image from gallery
    @IBAction func addImageBtn(_ sender: UIButton) {
        showPickerController()
    }
    
    
    //add movie to "my movies" array then go to my movies
    @IBAction func add_movie(_ sender: UIButton) {
        setEncodedImage(galleryImage: posterImageView.image!)
        
        //must have a title
        if (titleTextField.text == ""){
            let alert = UIAlertController(title: "Must add a title for your Movie", message: "", preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { (action) in
                
            }))
        
            
            present(alert, animated: true, completion: nil)
        }
       
        let newMovie = MovieModel.init(title: titleTextField.text!, overview: overviewTextField.text!, release_date: dateTextField.text!, poster_path: encodedImage )
        
        
        var myMovieArray = decodeMoviesArray()
        myMovieArray.append(newMovie)
        //store the array again after adding new movie to it
        encodeMoviesArray(myMovies:myMovieArray)
 
        self.performSegue(withIdentifier: "goToMyMovies", sender: self)

    }
    
    
    
    
    func encodeMoviesArray(myMovies: [MovieModel]){
        do{
                   let data = try encoder.encode(myMovies)
                   
                   try data.write(to: self.dataFilePath!)
               }
               catch{
                   print("Error encoding movies array, \(error)")
               }
        
    }
    
    func decodeMoviesArray()->[MovieModel]{
        
        var movies = [MovieModel]()
        if let data = try? Data(contentsOf: self.dataFilePath!){
            let decoder = PropertyListDecoder()
            
            do{
                
               let movieArray = try decoder.decode([MovieModel].self, from: data)
                movies = movieArray
              
            }catch{
                print("Error deccoding movies array, \(error)")

            }
        }

        return movies
    }
    
    
    
    
    
    func setEncodedImage(galleryImage:UIImage){
        self.encodedImage = self.encodeImage(image: galleryImage)
    }
    
    
    //UIImage Base64 Encoding to be able to store it in a plist

    func encodeImage(image:UIImage)-> String{
           
           let imageData = image.jpegData(compressionQuality: 1)
           let imageBase64String = (imageData?.base64EncodedString())!
       return imageBase64String
    

       }
    
  
    
    
}





extension AddMovieViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    
    func showPickerController(){
        
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        imagePicker.sourceType = .photoLibrary
        
        present(imagePicker, animated: true, completion: nil)

        
    }
    
    
     func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])  {
            
          

           if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage{
                posterImageView.image = image
                setEncodedImage(galleryImage: image)
           } else if let image2 = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
                       posterImageView.image = image2
                        setEncodedImage(galleryImage: image2)
                   }
            

            
            dismiss(animated: true, completion: nil)
        }
        
        func getDocumentsDirectory() -> URL {
            let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            return paths[0]
        }
        
    
        
    }
