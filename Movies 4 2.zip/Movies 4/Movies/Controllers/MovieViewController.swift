
import UIKit

class MovieViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {

    let moviesURL = "https://api.themoviedb.org/3/movie/popular?api_key=acea91d2bff1c53e6604e4985b6989e2&language=en-US"
    var results = [MovieModel]()
    let encoder  = PropertyListEncoder()
    var pageNumber = 1
    var fetchingMore = false
   
   
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.fetchMovies(pageNumber: pageNumber)
        tableView.delegate = self
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        
        
        if offsetY > contentHeight - scrollView.frame.height * 4 {
            if !fetchingMore {
                pageNumber = pageNumber + 1
                fetchMovies(pageNumber: pageNumber)
            }
            
        }
    }

    //fetch movies from page
    func fetchMovies(pageNumber: Int) {
        fetchingMore = true
        let urlString = "\(moviesURL)&page=\(pageNumber)"
        self.performRequest(urlString: urlString)
    }
    

    //retrieve data from API
    func performRequest(urlString: String) {
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            let task = session.dataTask(with: url) { (data, response, error) in if error != nil {
                print(error!)
                return
                }
                
                if let safeData = data {
                    if let results = self.parseJSON(movieData: safeData) {
                        DispatchQueue.main.async {
                            self.results.append(contentsOf: results)
                            self.fetchingMore = false
                            self.tableView.reloadData()
                        }
                    }
                }
                
                
            }
            task.resume()
            
        }
    }

    
    func parseJSON(movieData: Data) -> [MovieModel]? {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(MoviesModel.self, from: movieData)
            let results = decodedData.results
            return results
        } catch {
            print(error)
            return nil
        }
    }
    
    

    //table view methods//////////
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return results.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MovieItemCell") as? MovieCell else {
            return UITableViewCell()
        }
        
        cell.titleLabel.text = results[indexPath.row].title
        cell.overviewLabel.text = results[indexPath.row].overview
        cell.dateLabel.text = results[indexPath.row].release_date
        
        cell.imgView.clipsToBounds = true
        cell.imgView.contentMode = .scaleAspectFit
        cell.imgView.image = nil
        let url = URL(string: "https://image.tmdb.org/t/p/original/\(results[indexPath.row].poster_path)")!
        cell.imgView?.load(url: url)
        return cell
        
    }
    
    
    
    
    
   

    
    //Segue Methods////////////////
    
    //go to add new Movie
    @IBAction func addNewMovieAction(_ sender: UIButton) {
        

        self.performSegue(withIdentifier: "goToAddMovie", sender: self)
    
    }
    
    //go to my movies
    @IBAction func goToMyMoviesAction(_ sender: UIButton) {
        
        self.performSegue(withIdentifier: "myMovieSegue", sender: self)
           
    }
    
    
}

//retrieve movie poster
extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}


