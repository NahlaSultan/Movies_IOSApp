import UIKit

class MyMovieViewController: UIViewController,  UITableViewDataSource,UITableViewDelegate {
    
  
    var myMovies = [MovieModel]()
    let dataFilePath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("MyMovies.plist")
   
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        tableView.dataSource = self

        myMovies = decodeMoviesArray()
        
        
    
      }
    
//tableViewMethods
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
   return UITableView.automaticDimension
}

func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return myMovies.count
}

//populate table view cells from saved "my movies"
func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    guard let cell = tableView.dequeueReusableCell(withIdentifier: "MovieItemCell") as? MovieCell else {
        return UITableViewCell()
    }
    
 

    cell.titleLabel.text = myMovies[indexPath.row].title
    cell.overviewLabel.text = myMovies[indexPath.row].overview
    cell.dateLabel.text = myMovies[indexPath.row].release_date

    
    cell.imgView.clipsToBounds = true
    cell.imgView.contentMode = .scaleAspectFit

    cell.imgView?.image = decodeImage(encodedImage:  myMovies[indexPath.row].poster_path)
    return cell
    
}






func decodeMoviesArray()->[MovieModel]{
    
    var movies = [MovieModel]()
    if let data = try? Data(contentsOf: self.dataFilePath!){
        let decoder = PropertyListDecoder()
        
        do{
            
           let movieArray = try decoder.decode([MovieModel].self, from: data)
            movies = movieArray
          
        }catch{
            print("Error deccoding movies array, \(error)")

        }
    }
    
    tableView.reloadData()


    return movies
}

func decodeImage(encodedImage:String)->UIImage {
      
      let newImageData = Data(base64Encoded: encodedImage)
      return UIImage(data: newImageData!)!


       }

}
