//
//  MovieModel.swift
//  Movies
//
//  Copyright © 2020 Nahla. All rights reserved.
//

import UIKit

class MoviesModel: Codable {
    let results: [MovieModel]
    init(results: [MovieModel]) {
        self.results = results
    }
}


class MovieModel: Codable {
    let title: String
    let overview: String
    let release_date: String
    let poster_path: String

    
    init(title: String, overview: String, release_date: String, poster_path: String) {
        self.title = title
        self.overview = overview
        self.release_date = release_date
        self.poster_path = poster_path
        
    }
    
   
}
