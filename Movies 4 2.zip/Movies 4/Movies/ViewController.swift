import UIKit

class AddMovieViewController: UIViewController {
    
    @IBOutlet weak var titleTextField: UITextField!
        
    @IBOutlet weak var overviewTextField: UITextField!
        
    @IBOutlet weak var dateTextField: UITextField!
    
    @IBOutlet weak var posterImageView: UIImageView!
    
    @IBOutlet weak var addImageView: UIImageView!
    
    let encoder  = PropertyListEncoder()

    let dataFilePath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("MyMovies.plist")
    

    var encodedImage = ""
    var movieArray = [MovieModel]()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
  
    }
    
    
    
    
    @IBAction func addImageBtn(_ sender: UIButton) {
        
        showPickerController()
        
    }
    
    
    // Add the actions




   
    @IBAction func add_movie(_ sender: UIButton) {
        
        setEncodedImage(galleryImage: posterImageView.image!)

       
        let newMovie = MovieModel.init(title: titleTextField.text!, overview: overviewTextField.text!, release_date: dateTextField.text!, poster_path: encodedImage )
        
       
        
        let myMovieView = MyMovieViewController()
        myMovieView.myMovies.append(newMovie)
        
        encodeMoviesArray(myMovies: myMovieView.myMovies)

       
        
        present(myMovieView, animated: true, completion: nil)


    }
    
    
    
    
    func encodeMoviesArray(myMovies: [MovieModel]){
        do{
                   let data = try encoder.encode(myMovies)
                   
                   try data.write(to: self.dataFilePath!)
               }
               catch{
                   print("Error encoding movies array, \(error)")
               }
        
    }
    
    func decodeMoviesArray()->[MovieModel]{
        
        var movies = [MovieModel]()
        if let data = try? Data(contentsOf: self.dataFilePath!){
            let decoder = PropertyListDecoder()
            
            do{
                
               let movieArray = try decoder.decode([MovieModel].self, from: data)
                movies = movieArray
              
            }catch{
                print("Error deccoding movies array, \(error)")

            }
        }

        return movies
    }
    
    
    
    
    
    func setEncodedImage(galleryImage:UIImage){
        self.encodedImage = self.encodeImage(image: galleryImage)
    }
    
    
    //UIImage Base64 Encoding and Decoding
   
    func encodeImage(image:UIImage)-> String{
           
           let imageData = image.jpegData(compressionQuality: 1)
           let imageBase64String = (imageData?.base64EncodedString())!
       return imageBase64String
    

       }
    
  
    
    
}





extension AddMovieViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    
    func showPickerController(){
        
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        imagePicker.sourceType = .photoLibrary
        
        present(imagePicker, animated: true, completion: nil)

        
    }
    
    
     func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])  {
            
          

           if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage{
                posterImageView.image = image
                setEncodedImage(galleryImage: image)
           } else if let image2 = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
                       posterImageView.image = image2
                        setEncodedImage(galleryImage: image2)
                   }
            

            
            dismiss(animated: true, completion: nil)
        }
        
        func getDocumentsDirectory() -> URL {
            let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            return paths[0]
        }
        
    
        
    }
